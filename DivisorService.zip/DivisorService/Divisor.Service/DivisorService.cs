﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Divisor.Service
{
    public class DivisorService
    {

        private IList<int> divisores;
        private IList<int> divisoresPrimos;

        public DivisorService()
        {
            divisores = new List<int>();
            divisoresPrimos = new List<int>();
        }

        public bool NumeroPrimo(int valor)
        {
            if (valor < 2)
            {
                return false;
            }

            for (var divisor = 2; divisor <= Math.Sqrt(valor); divisor++)
            {
                if (valor % divisor == 0)
                {
                    return false;
                }
            }
            return true;
        }

        //
        public (IList<int>, IList<int>) DivisoresPositivos(int valor)
        {

            int raizValor = (int)Math.Sqrt(valor);

            if(valor > 1)
            {
                //Busca apenas até a raiz quadrada de valor
                for (int i = 1; i <= raizValor; i++)
                {
                    if (valor % i == 0)
                    {
                        if (!divisores.Contains(i))
                            divisores.Add(i);
                        if (!divisores.Contains(valor / i))
                            divisores.Add(valor / i);

                        if (NumeroPrimo(i))
                        {
                            if (!divisoresPrimos.Contains(i))
                                divisoresPrimos.Add(i);
                        }
                        if (NumeroPrimo(valor / i))
                        {
                            if (!divisoresPrimos.Contains(valor / i))
                                divisoresPrimos.Add(valor / i);
                        }
                    }
                }
            }
            //Se valor for quadrado perfeito também adiciona a raiz de valor
            if (raizValor * raizValor == valor)
            {
                if (!divisores.Contains(raizValor))
                    divisores.Add(raizValor);

                if (!divisoresPrimos.Contains(raizValor))
                    if (NumeroPrimo(raizValor))
                    {
                        divisoresPrimos.Add(raizValor);
                    }                  
            }

            return (divisores.OrderBy(x=>x).ToList(), divisoresPrimos.OrderBy(x => x).ToList());
        }

    }
}
