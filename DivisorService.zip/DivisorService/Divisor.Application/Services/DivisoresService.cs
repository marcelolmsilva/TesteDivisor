﻿using Divisor.Application.Services.Interfaces;
using Divisor.Domain.Entities.Lista;
using Divisor.Service;
using System.Threading.Tasks;

namespace Divisor.Application.Services
{
    public class DivisoresService : IDivisoresService
    {
        public async Task<ListaDivisores> GetdivisoresLista(int valor)
        {
            ListaDivisores lista = new ListaDivisores();
            DivisorService ds = new DivisorService();
            
            (lista.divisores,lista.divisoresPrimos) = ds.DivisoresPositivos(valor);
            return lista;
        }
    }
}
