﻿using Divisor.Domain.Entities.Lista;
using System.Threading.Tasks;

namespace Divisor.Application.Services.Interfaces
{
    public interface IDivisoresService
    {
        public Task<ListaDivisores> GetdivisoresLista(int valor);

    }
}
