using Xunit;

namespace Divisor.Service.Tests
{
    public class DivisorServiceTest
    {
        private readonly DivisorService _divisorService;
        public DivisorServiceTest()
        {
            _divisorService = new DivisorService();
        }

        #region NumeroPrimo
        /*Testa M�todo NumeroPrimo */

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        [InlineData(1)]
        public void NumeroPrimo_ValorMenorDoQueDois_RetornaFalso(int value)
        {
            var result = _divisorService.NumeroPrimo(value);

            Assert.False(result, $"{value} n�o � n�mero primo.");
        }
      

        [Theory]
        [InlineData(2)]
        [InlineData(3)]
        [InlineData(5)]
        [InlineData(7)]
        public void NumeroPrimo_PrimoMenorDoQueDez_RetornaVerdadeiro(int value)
        {
            var result = _divisorService.NumeroPrimo(value);

            Assert.True(result, $"{value} � n�mero primo.");
        }

        [Theory]
        [InlineData(4)]
        [InlineData(6)]
        [InlineData(8)]
        [InlineData(9)]
        public void NumeroPrimo_NaoPrimoMenorDoQueDez_RetornaFalso(int value)
        {
            var result = _divisorService.NumeroPrimo(value);

            Assert.False(result, $"{value} n�o � n�mero primo.");
        }

        #endregion


        #region Divisores_Positivos
        /*Testa M�todo Divisores Positivos*/
 
        [Theory]
        [InlineData(-1)]
        public void DivisoresPositivos_ValorMenorDoQueZero_RetornaFalso(int value)
        {
            //Act
            var (result, result1) = _divisorService.DivisoresPositivos(value);
            //Assert
            Assert.False(result.Count != 0, $"{value} deve ser maior que zero.");
            Assert.False(result1.Count != 0, $"{value} deve ser maior que zero.");
        }

        [Theory]
        [InlineData(0)]
        [InlineData(1)]
        public void DivisoresPositivos_ValorIqualZeroOuUm_RetornaVerdadeiro(int value)
        {
            //Act
            var (result, result1) = _divisorService.DivisoresPositivos(value);
            //Assert
            Assert.True(result.Contains(value), $"{value} tem divisor");
            Assert.False(result1.Count != 0, $"{value} tem divisor n�o primo");
        }

        [Theory]
        [InlineData(2)]
        [InlineData(3)]
        [InlineData(4)]
        [InlineData(5)]
        [InlineData(6)]
        [InlineData(7)]
        [InlineData(8)]
        [InlineData(9)]
        [InlineData(15)]
        [InlineData(45)]
        [InlineData(196)]
        [InlineData(360)]
        public void DivisoresPositivos_ValorMaiorDoQueUm_RetornaTrue(int value)
        {
            //Act
            var (result, result1) = _divisorService.DivisoresPositivos(value);
            //Assert
            Assert.True(result.Contains(value), $"{value} tem divisor");
            Assert.True(result1.Count != 0, $"{value} tem divisor primo");
        }

        #endregion
    }
}
