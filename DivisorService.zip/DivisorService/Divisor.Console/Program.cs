﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Divisor.Service
{
    class Program
    {
        static public IList<int> divisores;
        static public IList<int> divisoresPrimos;

        static void Main(string[] args)
        {

            Console.WriteLine("Digite um número inteiro positivo:");
            int numero = Convert.ToInt32(Console.ReadLine());
            //
            DivisorService ds = new DivisorService();
            (divisores, divisoresPrimos) = ds.DivisoresPositivos(numero);

            Console.WriteLine($"Números divisores:");
            foreach (var item in divisores.OrderBy(x => x))
            {
                Console.WriteLine($"{item}");
            }

            Console.WriteLine($"Divisores Primos:");
            foreach (var item in divisoresPrimos.OrderBy(x => x))
            {
                Console.WriteLine($"{item}");
            }

            Console.ReadKey();
        }
    }
}
