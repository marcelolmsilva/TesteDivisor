﻿using System.Threading.Tasks;
using Divisor.Application.Services.Interfaces;
using Divisor.Domain.Entities.Lista;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Divisor.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DivisoresController : ControllerBase
    {
        private readonly ILogger<DivisoresController> _logger;
        private readonly IDivisoresService _divisoresService;

        public DivisoresController(ILogger<DivisoresController> logger, IDivisoresService divisoresService)
        {
            _logger = logger;
            _divisoresService = divisoresService;
        }


        [HttpGet("{numero}")]
        public async Task<ListaDivisores> GetAll(int numero)
        {
            _logger.LogInformation($"Getting id {numero}");
            return await _divisoresService.GetdivisoresLista(numero);
        }


    }
}