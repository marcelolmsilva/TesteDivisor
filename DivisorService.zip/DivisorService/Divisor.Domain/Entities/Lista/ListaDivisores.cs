﻿using System.Collections.Generic;

namespace Divisor.Domain.Entities.Lista
{
    public class ListaDivisores
    {     
        public IList<int> divisores { get; set; }
        public IList<int> divisoresPrimos { get; set; }
    }
}
